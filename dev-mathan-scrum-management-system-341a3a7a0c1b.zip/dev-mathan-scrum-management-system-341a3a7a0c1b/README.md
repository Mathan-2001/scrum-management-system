# Scrum Management System

Full-stack Scrum Management System with OTP login, role-based dashboards, user creation, and daily standup reporting. Data is stored in PostgreSQL through Prisma.

## Stack

- Frontend: Next.js App Router, TypeScript, Tailwind CSS, React Hook Form, Zod, TanStack Query, Axios
- Backend: Node.js, Express, Prisma, PostgreSQL, JWT, Nodemailer
- Storage: PostgreSQL tables for users, OTPs, standups, and standup task rows

## Setup

1. Install dependencies:

```bash
npm install
```

2. Create the backend environment file:

```bash
copy backend\.env.example backend\.env
```

Set `DATABASE_URL` to your PostgreSQL connection string. The backend defaults to port `4000`, allows the local frontend, and logs OTP emails to the console when SMTP is not configured.

3. Apply the Prisma schema:

```bash
npm run db:deploy --workspace backend
```

For local development with migration creation, use:

```bash
npm run db:migrate --workspace backend
```

4. Run the backend:

```bash
npm run dev:backend
```

5. Run the frontend in another terminal:

```bash
npm run dev:frontend
```

Frontend: http://localhost:3000

Backend: http://localhost:4000

## Production-style Build

```bash
npm run build
npm run db:deploy --workspace backend
npm run start --workspace backend
npm run start --workspace frontend
```

If port `3000` is already busy, start the frontend on `3001`:

```bash
npm run start --workspace frontend -- -p 3001
```

Set `DATABASE_URL` and `JWT_SECRET` before showing this outside your machine. Set `FRONTEND_URL` or `FRONTEND_URLS` if the frontend is hosted anywhere other than localhost.

## Render Deployment

This repo includes `render.yaml` for a two-service Render deploy:

- `scrum-sms-frontend`: Next.js frontend
- `scrum-sms-backend`: Express API
- `scrum-sms-db`: free Render Postgres database

Render injects `DATABASE_URL` into the backend from `scrum-sms-db`. After Render creates the services, set these environment values:

- Frontend service: `NEXT_PUBLIC_API_URL=https://your-backend-service.onrender.com`
- Backend service: `FRONTEND_URL=https://your-frontend-service.onrender.com`
- Backend service: `FRONTEND_URLS=https://your-frontend-service.onrender.com`

Render's free Postgres plan is useful for demos, but free databases expire after 30 days and do not include backups. Upgrade the database before storing important production data.

If you deploy only the frontend service from the repository root, Render can use:

```bash
npm run build --workspace frontend
npm start
```

The root `npm start` command starts the frontend on Render's assigned `PORT`.

## Demo Accounts

Use any seeded email and request an OTP. In development, the backend logs OTP emails to the console when SMTP is not configured.

- Super Admin: `superadmin@scrum.local`
- Admin: `admin@scrum.local`
- User: `mathan@scrum.local`

## Reset Demo Data

Delete all rows from the PostgreSQL tables or recreate the database, then start the backend again. The three demo users above are seeded automatically when the users table is empty.
