import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        border: "var(--border)",
        ink: "var(--ink)",
        muted: "var(--muted)",
        panel: "var(--panel)",
        app: "var(--app)",
        brand: "var(--brand)",
        accent: "var(--accent)"
      }
    }
  },
  plugins: []
};

export default config;
