"use client";

import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { StandupsTable } from "@/components/standups-table";
import { Button, CustomSelect, DateControl, Field, Input } from "@/components/ui";
import { api } from "@/lib/api";
import { StandupRecord } from "@/lib/types";

export default function StandupsPage() {
  const [filters, setFilters] = useState({ date: "", employee: "", role: "", status: "" });
  const params = useMemo(
    () => Object.fromEntries(Object.entries(filters).filter(([, value]) => value)),
    [filters]
  );

  const { data = [] } = useQuery({
    queryKey: ["standups", params],
    queryFn: async () => (await api.get<StandupRecord[]>("/standups", { params })).data
  });

  function exportCsv() {
    const header = ["Employee ID", "Name", "Role", "Date", "Project Name", "Task ID", "Task Description", "Time Spent", "Task Status", "Blockers", "Status"];
    const rows = data.flatMap((item) => item.tasks.map((task) => [
        item.user.employeeId,
        item.user.name,
        item.user.role,
        new Date(item.date).toLocaleDateString(),
        task.projectName,
        task.taskId,
        task.taskDescription,
        String(task.timeSpent),
        task.taskStatus,
        task.blockers ?? "",
        item.status
      ]));
    const csv = [header, ...rows].map((row) => row.map((cell) => `"${cell.replaceAll('"', '""')}"`).join(",")).join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = "daily-standups.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <AppShell
      role="SUPER_ADMIN"
      title="Daily Standups"
      description="Monitor team updates from a single screen."
      actions={(
        <Button onClick={exportCsv}>
          <Download size={18} />
          Export Excel
        </Button>
      )}
    >
      <div className="grid gap-6">
        <div className="app-surface grid gap-3 rounded-lg p-4 md:grid-cols-4">
          <Field label="Date">
            <DateControl value={filters.date} onChange={(date) => setFilters((current) => ({ ...current, date }))} />
          </Field>
          <Field label="Employee">
            <Input value={filters.employee} onChange={(event) => setFilters((current) => ({ ...current, employee: event.target.value }))} placeholder="EMP101" />
          </Field>
          <Field label="Role">
            <CustomSelect
              value={filters.role}
              onChange={(role) => setFilters((current) => ({ ...current, role }))}
              options={[{ label: "All Roles", value: "" }, { label: "Admin", value: "ADMIN" }, { label: "User", value: "USER" }]}
            />
          </Field>
          <Field label="Status">
            <CustomSelect
              value={filters.status}
              onChange={(status) => setFilters((current) => ({ ...current, status }))}
              options={[{ label: "All Statuses", value: "" }, { label: "Submitted", value: "SUBMITTED" }, { label: "Pending", value: "PENDING" }]}
            />
          </Field>
        </div>
        <StandupsTable data={data} />
      </div>
    </AppShell>
  );
}
