import { AppShell } from "@/components/app-shell";

export default function SettingsPage() {
  return (
    <AppShell role="SUPER_ADMIN" title="Settings" description="System settings placeholder for SMTP, organization, and access policies.">
      <div className="rounded-lg border border-border bg-white p-5">
        <p className="text-sm font-medium text-slate-500">System settings placeholder for SMTP, organization, and access policies.</p>
      </div>
    </AppShell>
  );
}
