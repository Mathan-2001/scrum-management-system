import { AppShell } from "@/components/app-shell";
import { ProfileCard } from "@/components/profile-card";

export default function ProfilePage() {
  return (
    <AppShell role="SUPER_ADMIN" title="Profile" description="Profile details will appear here.">
      <ProfileCard />
    </AppShell>
  );
}
