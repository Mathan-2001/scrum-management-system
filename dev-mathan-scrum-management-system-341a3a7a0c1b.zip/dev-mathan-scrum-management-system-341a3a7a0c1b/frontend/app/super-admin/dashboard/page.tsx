"use client";

import { useQuery } from "@tanstack/react-query";
import { Activity, CheckCircle2, Clock3, ShieldCheck, Users } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { api } from "@/lib/api";

type Dashboard = {
  totalUsers: number;
  totalAdmins: number;
  submittedToday: number;
  pendingStandups: number;
  recentActivities: string[];
};

export default function SuperAdminDashboard() {
  const { data } = useQuery({
    queryKey: ["dashboard", "super-admin"],
    queryFn: async () => (await api.get<Dashboard>("/dashboard")).data
  });
  const totalPeople = (data?.totalUsers ?? 0) + (data?.totalAdmins ?? 0);
  const expectedStandups = data?.totalUsers ?? 0;
  const completionRate = expectedStandups > 0 ? Math.round(((data?.submittedToday ?? 0) / expectedStandups) * 100) : 0;
  const userShare = totalPeople > 0 ? Math.round(((data?.totalUsers ?? 0) / totalPeople) * 100) : 0;
  const adminShare = totalPeople > 0 ? Math.round(((data?.totalAdmins ?? 0) / totalPeople) * 100) : 0;
  const stats = [
    { label: "Total Users", value: data?.totalUsers ?? 0, icon: Users, accent: "bg-teal-50 text-teal-700" },
    { label: "Total Admins", value: data?.totalAdmins ?? 0, icon: ShieldCheck, accent: "bg-indigo-50 text-indigo-700" },
    { label: "Submitted Today", value: data?.submittedToday ?? 0, icon: CheckCircle2, accent: "bg-emerald-50 text-emerald-700" },
    { label: "Pending Standups", value: data?.pendingStandups ?? 0, icon: Clock3, accent: "bg-amber-50 text-amber-700" }
  ];

  return (
    <AppShell role="SUPER_ADMIN" title="Dashboard" description="System-wide people and standup activity.">
      <div className="grid gap-6">
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="app-surface rounded-lg p-5">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">{stat.label}</div>
                    <div className="mt-2 text-3xl font-bold tracking-tight text-slate-950">{stat.value}</div>
                  </div>
                  <div className={`flex h-11 w-11 items-center justify-center rounded-lg ${stat.accent}`}>
                    <Icon size={21} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="grid gap-4 xl:grid-cols-[1fr_1.2fr]">
          <section className="app-surface rounded-lg p-5">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-slate-950">Standup Completion</h3>
                <p className="mt-1 text-sm font-medium text-slate-500">Today&apos;s submitted reports versus expected user reports.</p>
              </div>
              <Activity className="text-slate-400" size={20} />
            </div>
            <div className="mt-6 flex items-center gap-6">
              <div
                className="grid h-36 w-36 shrink-0 place-items-center rounded-full"
                style={{ background: `conic-gradient(#0f766e ${completionRate * 3.6}deg, #e5e7eb 0deg)` }}
              >
                <div className="grid h-24 w-24 place-items-center rounded-full bg-white text-center shadow-inner">
                  <div>
                    <div className="text-3xl font-bold text-slate-950">{completionRate}%</div>
                    <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">Complete</div>
                  </div>
                </div>
              </div>
              <div className="grid flex-1 gap-3 text-sm">
                <div className="flex items-center justify-between rounded-md bg-slate-50 px-3 py-2">
                  <span className="font-medium text-slate-600">Submitted</span>
                  <span className="font-bold text-slate-950">{data?.submittedToday ?? 0}</span>
                </div>
                <div className="flex items-center justify-between rounded-md bg-slate-50 px-3 py-2">
                  <span className="font-medium text-slate-600">Pending</span>
                  <span className="font-bold text-slate-950">{data?.pendingStandups ?? 0}</span>
                </div>
                <div className="flex items-center justify-between rounded-md bg-slate-50 px-3 py-2">
                  <span className="font-medium text-slate-600">Expected</span>
                  <span className="font-bold text-slate-950">{expectedStandups}</span>
                </div>
              </div>
            </div>
          </section>

          <section className="app-surface rounded-lg p-5">
            <h3 className="text-base font-bold text-slate-950">People Distribution</h3>
            <p className="mt-1 text-sm font-medium text-slate-500">Role split across the current workspace.</p>
            <div className="mt-6 grid gap-5">
              <div>
                <div className="mb-2 flex items-center justify-between text-sm">
                  <span className="font-semibold text-slate-700">Users</span>
                  <span className="font-bold text-slate-950">{userShare}%</span>
                </div>
                <div className="h-3 overflow-hidden rounded-md bg-slate-100">
                  <div className="h-full rounded-md bg-teal-600" style={{ width: `${userShare}%` }} />
                </div>
              </div>
              <div>
                <div className="mb-2 flex items-center justify-between text-sm">
                  <span className="font-semibold text-slate-700">Admins</span>
                  <span className="font-bold text-slate-950">{adminShare}%</span>
                </div>
                <div className="h-3 overflow-hidden rounded-md bg-slate-100">
                  <div className="h-full rounded-md bg-indigo-600" style={{ width: `${adminShare}%` }} />
                </div>
              </div>
            </div>
          </section>
        </div>

        <section className="app-surface rounded-lg p-5">
          <h3 className="text-base font-bold text-slate-950">Recent Activities</h3>
          <div className="mt-3 grid gap-2 text-sm">
            {(data?.recentActivities ?? ["No activity yet"]).map((activity) => (
              <div key={activity} className="rounded-md border border-slate-100 bg-slate-50 px-3 py-2 font-medium text-slate-600">
                {activity}
              </div>
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
