"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { Pencil, Plus, Trash2, X } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { AppShell } from "@/components/app-shell";
import { useToast } from "@/components/toast";
import {
  Button,
  CustomSelect,
  Field,
  IconButton,
  Input,
  SecondaryButton,
  StatusBadge,
} from "@/components/ui";
import { api } from "@/lib/api";
import { UserRecord } from "@/lib/types";

const userSchema = z.object({
  name: z.string().min(3, "Minimum 3 characters"),
  employeeId: z.string().min(1, "Employee ID is required"),
  role: z.enum(["ADMIN", "USER"], { required_error: "Role is required" }),
  email: z.string().email("Enter a valid email"),
});

export default function UsersPage() {
  const [open, setOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<UserRecord | null>(null);
  const queryClient = useQueryClient();
  const toast = useToast();
  const form = useForm<z.infer<typeof userSchema>>({
    resolver: zodResolver(userSchema),
    defaultValues: { name: "", employeeId: "", role: "USER", email: "" },
  });

  const { data = [] } = useQuery({
    queryKey: ["users"],
    queryFn: async () => (await api.get<UserRecord[]>("/users")).data,
  });

  const createUser = useMutation({
    mutationFn: async (values: z.infer<typeof userSchema>) =>
      (await api.post("/users", values)).data,
    onSuccess: async () => {
      toast.success("User created and welcome email sent.");
      form.reset();
      setOpen(false);
      await queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (error: any) =>
      toast.error(error.response?.data?.message ?? "Unable to create user"),
  });

  const updateUser = useMutation({
    mutationFn: async (values: z.infer<typeof userSchema>) => {
      if (!editingUser) throw new Error("No user selected");
      return (await api.patch(`/users/${editingUser.id}`, values)).data;
    },
    onSuccess: async () => {
      toast.success("User updated successfully.");
      form.reset({ name: "", employeeId: "", role: "USER", email: "" });
      setEditingUser(null);
      setOpen(false);
      await queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (error: any) =>
      toast.error(error.response?.data?.message ?? "Unable to update user"),
  });

  const deleteUser = useMutation({
    mutationFn: async (userId: string) =>
      (await api.delete(`/users/${userId}`)).data,
    onSuccess: async () => {
      toast.success("User deleted successfully.");
      await queryClient.invalidateQueries({ queryKey: ["users"] });
    },
    onError: (error: any) =>
      toast.error(error.response?.data?.message ?? "Unable to delete user"),
  });

  function handleDelete(user: UserRecord) {
    const confirmed = window.confirm(
      `Delete ${user.name}? This will remove the user and their demo standup history.`,
    );
    if (confirmed) deleteUser.mutate(user.id);
  }

  function openCreate() {
    setEditingUser(null);
    form.reset({ name: "", employeeId: "", role: "USER", email: "" });
    setOpen(true);
  }

  function openEdit(user: UserRecord) {
    setEditingUser(user);
    form.reset({
      name: user.name,
      employeeId: user.employeeId,
      role: user.role === "ADMIN" ? "ADMIN" : "USER",
      email: user.email,
    });
    setOpen(true);
  }

  function closePanel() {
    setOpen(false);
    setEditingUser(null);
    form.reset({ name: "", employeeId: "", role: "USER", email: "" });
  }

  return (
    <AppShell
      role="SUPER_ADMIN"
      title="Users"
      description="Create admins and users, then manage their access."
      actions={
        <Button onClick={openCreate}>
          <Plus size={18} />
          Create User
        </Button>
      }
    >
      <div className="grid gap-6">
        <div className="app-table-shell thin-scrollbar max-h-[620px] overflow-auto rounded-lg">
          <table className="w-full min-w-[860px] border-separate border-spacing-0 text-left text-sm">
            <thead className="sticky top-0 z-20 bg-[#0f172a] text-xs uppercase tracking-wide text-white shadow-sm">
              <tr>
                <th className="px-5 py-4 font-bold">Employee ID</th>
                <th className="px-5 py-4 font-bold">Name</th>
                <th className="px-5 py-4 font-bold">Role</th>
                <th className="px-5 py-4 font-bold">Email</th>
                <th className="px-5 py-4 font-bold">Status</th>
                <th className="px-5 py-4 text-right font-bold">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white">
              {data.length === 0 ? (
                <tr>
                  <td
                    className="px-5 py-10 text-center text-slate-500"
                    colSpan={6}
                  >
                    No users found.
                  </td>
                </tr>
              ) : (
                data.map((user) => (
                  <tr
                    key={user.id}
                    className="text-slate-800 transition hover:bg-slate-50"
                  >
                    <td className="border-b border-slate-200 px-5 py-4 text-slate-950">
                      {user.employeeId}
                    </td>
                    <td className="border-b border-slate-200 px-5 py-4 text-slate-950">
                      {user.name}
                    </td>
                    <td className="border-b border-slate-200 px-5 py-4 text-slate-600">
                      {user.role.replace("_", " ")}
                    </td>
                    <td className="border-b border-slate-200 px-5 py-4">
                      {user.email}
                    </td>
                    <td className="border-b border-slate-200 px-5 py-4">
                      <StatusBadge>
                        {user.isActive === false ? "Inactive" : "Active"}
                      </StatusBadge>
                    </td>
                    <td className="border-b border-slate-200 px-5 py-4 text-right">
                      <div className="flex justify-end gap-2">
                        <IconButton
                          disabled={user.role === "SUPER_ADMIN"}
                          onClick={() => openEdit(user)}
                          type="button"
                          aria-label={`Edit ${user.name}`}
                          title={`Edit ${user.name}`}
                          tone="teal"
                        >
                          <Pencil className="" size={16} />
                        </IconButton>
                        <IconButton
                          disabled={
                            deleteUser.isPending || user.role === "SUPER_ADMIN"
                          }
                          onClick={() => handleDelete(user)}
                          type="button"
                          aria-label={`Delete ${user.name}`}
                          title={`Delete ${user.name}`}
                          tone="red"
                        >
                          <Trash2 className="" size={16} />
                        </IconButton>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {open ? (
        <div className="fixed inset-0 z-30 bg-black/25">
          <aside className="ml-auto h-full w-full max-w-md overflow-y-auto border-l border-border bg-panel p-5 shadow-xl">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-ink">
                {editingUser ? "Edit User" : "Create User"}
              </h3>
              <button
                className="rounded-md p-2 hover:bg-slate-50"
                onClick={closePanel}
              >
                <X size={20} />
              </button>
            </div>
            <form
              className="grid gap-4"
              onSubmit={form.handleSubmit((values) =>
                editingUser
                  ? updateUser.mutate(values)
                  : createUser.mutate(values),
              )}
            >
              <Field
                label="User Name"
                error={form.formState.errors.name?.message}
              >
                <Input {...form.register("name")} />
              </Field>
              <Field
                label="Employee ID"
                error={form.formState.errors.employeeId?.message}
              >
                <Input {...form.register("employeeId")} />
              </Field>
              <Field label="Role" error={form.formState.errors.role?.message}>
                <CustomSelect
                  value={form.watch("role")}
                  onChange={(role) =>
                    form.setValue("role", role as "ADMIN" | "USER", {
                      shouldValidate: true,
                    })
                  }
                  options={[
                    { label: "Admin", value: "ADMIN" },
                    { label: "User", value: "USER" },
                  ]}
                />
              </Field>
              <Field label="Email" error={form.formState.errors.email?.message}>
                <Input type="email" {...form.register("email")} />
              </Field>
              {!editingUser ? (
                <div className="rounded-md bg-slate-50 px-3 py-2 text-sm text-muted">
                  Temporary password is generated automatically and sent by
                  email.
                </div>
              ) : null}
              <div className="flex gap-3">
                <Button
                  disabled={createUser.isPending || updateUser.isPending}
                  type="submit"
                >
                  {editingUser ? "Update" : "Submit"}
                </Button>
                <SecondaryButton type="button" onClick={closePanel}>
                  Cancel
                </SecondaryButton>
              </div>
            </form>
          </aside>
        </div>
      ) : null}
    </AppShell>
  );
}
