"use client";

import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { AppTooltip, StatusBadge } from "@/components/ui";
import { api } from "@/lib/api";
import { StandupRecord } from "@/lib/types";

export default function UserReportHistoryPage() {
  const { data = [] } = useQuery({
    queryKey: ["my-standup-history"],
    queryFn: async () => (await api.get<StandupRecord[]>("/standups/mine")).data
  });

  return (
    <AppShell role="USER" title="Report History" description="Your submitted daily standup reports.">
      <div className="grid gap-6">
        <div className="app-table-shell thin-scrollbar max-h-[620px] overflow-auto rounded-lg">
          <table className="w-full min-w-[1180px] border-separate border-spacing-0 text-left text-sm">
            <thead className="sticky top-0 z-20 bg-[#0f172a] text-xs uppercase tracking-wide text-white shadow-sm">
              <tr>
                <th className="px-5 py-4 font-bold">Date</th>
                <th className="px-5 py-4 font-bold">Project</th>
                <th className="px-5 py-4 font-bold">Task ID</th>
                <th className="px-5 py-4 font-bold">Task Description</th>
                <th className="px-5 py-4 font-bold">Time Spent</th>
                <th className="px-5 py-4 font-bold">Task Status</th>
                <th className="px-5 py-4 font-bold">Blockers</th>
                <th className="px-5 py-4 font-bold">Submitted</th>
              </tr>
            </thead>
            <tbody className="bg-white">
              {data.length === 0 ? (
                <tr>
                  <td className="px-5 py-10 text-center text-slate-500" colSpan={8}>No reports submitted yet.</td>
                </tr>
              ) : (
                data.map((item) =>
                  item.tasks.map((task, index) => (
                    <tr key={`${item.id}-${index}`} className="text-slate-800 transition hover:bg-slate-50">
                      {index === 0 ? (
                        <td className="align-middle border-b border-r border-slate-200 px-5 py-5 text-slate-950" rowSpan={item.tasks.length}>{new Date(item.date).toLocaleDateString()}</td>
                      ) : null}
                      <td className="border-b border-slate-200 px-5 py-4 align-top">{task.projectName}</td>
                      <td className="whitespace-nowrap border-b border-slate-200 px-5 py-4 align-top text-slate-950">{task.taskId}</td>
                      <td className="max-w-[360px] border-b border-slate-200 px-5 py-4 align-top leading-6">
                        <AppTooltip content={task.taskDescription}>
                          <span className="line-clamp-2 cursor-help">{task.taskDescription}</span>
                        </AppTooltip>
                      </td>
                      <td className="border-b border-slate-200 px-5 py-4 align-top">{task.timeSpent}</td>
                      <td className="whitespace-nowrap border-b border-slate-200 px-5 py-4 align-top"><StatusBadge tone="blue">{task.taskStatus}</StatusBadge></td>
                      <td className="border-b border-slate-200 px-5 py-4 align-top">{task.blockers || "-"}</td>
                      {index === 0 ? (
                        <td className="align-middle border-b border-slate-200 px-5 py-5 text-slate-700" rowSpan={item.tasks.length}>{new Date(item.submittedAt).toLocaleString()}</td>
                      ) : null}
                    </tr>
                  ))
                )
              )}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
