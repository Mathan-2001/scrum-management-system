import { AppShell } from "@/components/app-shell";
import { ProfileCard } from "@/components/profile-card";

export default function UserProfilePage() {
  return (
    <AppShell role="USER" title="My Profile" description="Profile details will appear here.">
      <ProfileCard />
    </AppShell>
  );
}
