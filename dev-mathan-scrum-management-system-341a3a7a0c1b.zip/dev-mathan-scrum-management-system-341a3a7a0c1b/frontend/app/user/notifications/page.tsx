import { AppShell } from "@/components/app-shell";

export default function NotificationsPage() {
  return (
    <AppShell role="USER" title="Notifications" description="No notifications yet.">
      <div className="rounded-lg border border-border bg-white p-5">
        <p className="text-sm font-medium text-slate-500">No notifications yet.</p>
      </div>
    </AppShell>
  );
}
