"use client";

import { useQuery } from "@tanstack/react-query";
import { CalendarCheck2, CheckCircle2, ClipboardList, Clock3 } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { api } from "@/lib/api";

type Dashboard = {
  welcomeName: string;
  todayStatus: string;
  pendingTasks: number;
  completedTasks: number;
  currentSprint: string;
};

export default function UserDashboard() {
  const { data } = useQuery({
    queryKey: ["dashboard", "user"],
    queryFn: async () => (await api.get<Dashboard>("/dashboard")).data
  });
  const submitted = data?.todayStatus === "Standup Submitted";
  const progress = submitted ? 100 : 35;
  const stats = [
    { label: "Today's Status", value: data?.todayStatus ?? "Pending", icon: CalendarCheck2, tone: "bg-teal-50 text-teal-700" },
    { label: "Pending Tasks", value: data?.pendingTasks ?? 0, icon: Clock3, tone: "bg-amber-50 text-amber-700" },
    { label: "Completed Tasks", value: data?.completedTasks ?? 0, icon: CheckCircle2, tone: "bg-emerald-50 text-emerald-700" },
    { label: "Current Sprint", value: data?.currentSprint ?? "Current Sprint", icon: ClipboardList, tone: "bg-indigo-50 text-indigo-700" }
  ];

  return (
    <AppShell role="USER" title={`Welcome ${data?.welcomeName ?? ""}`} description="Your activity summary for today.">
      <div className="grid gap-5">
        <section className="app-surface overflow-hidden rounded-lg">
          <div className="grid gap-5 p-5 lg:grid-cols-[1.3fr_0.7fr]">
            <div>
              <div className="inline-flex rounded-md bg-teal-50 px-2.5 py-1 text-xs font-medium text-teal-700">
                {submitted ? "Report completed" : "Report pending"}
              </div>
              <h2 className="mt-4 text-xl font-bold tracking-tight text-slate-950">Daily standup progress</h2>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-500">
                Keep your daily project updates structured with project-wise task entries and blockers.
              </p>
              <div className="mt-5 h-3 overflow-hidden rounded-full bg-slate-100">
                <div className="h-full rounded-full bg-teal-600 transition-all" style={{ width: `${progress}%` }} />
              </div>
            </div>
            <div className="rounded-lg bg-slate-950 p-5 text-white">
              <div className="text-xs font-medium uppercase tracking-wide text-slate-400">Next Action</div>
              <div className="mt-3 text-2xl font-bold">{submitted ? "Review history" : "Submit update"}</div>
              <p className="mt-2 text-sm leading-6 text-slate-300">
                {submitted ? "Your report is saved. You can review past updates from Report History." : "Add today's project tasks and submit before end of day."}
              </p>
            </div>
          </div>
        </section>
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div key={stat.label} className="app-surface rounded-lg p-5 transition hover:-translate-y-0.5 hover:shadow-md">
                <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${stat.tone}`}>
                  <Icon size={19} />
                </div>
                <div className="mt-4 text-xs font-medium uppercase tracking-wide text-slate-500">{stat.label}</div>
                <div className="mt-2 text-xl font-bold text-slate-950">{stat.value}</div>
              </div>
            );
          })}
        </div>
      </div>
    </AppShell>
  );
}
