"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { CalendarDays, Plus, Send, Trash2 } from "lucide-react";
import { useFieldArray, useForm } from "react-hook-form";
import { z } from "zod";
import { AppShell } from "@/components/app-shell";
import { useToast } from "@/components/toast";
import {
  Button,
  CustomSelect,
  DateControl,
  Field,
  IconButton,
  Input,
  SecondaryButton,
  Textarea,
} from "@/components/ui";
import { api } from "@/lib/api";

const schema = z.object({
  date: z.string().min(1, "Date is required"),
  tasks: z
    .array(
      z.object({
        projectName: z.string().min(1, "Project name is required"),
        taskId: z.string().min(1, "Task ID is required"),
        taskDescription: z.string().min(1, "Task description is required"),
        timeSpent: z.coerce.number().min(0, "Time spent must be positive"),
        taskStatus: z.string().min(1, "Status is required"),
        blockers: z.string().optional(),
      }),
    )
    .min(1, "Add at least one task"),
});

const emptyTask = {
  projectName: "",
  taskId: "",
  taskDescription: "",
  timeSpent: 0,
  taskStatus: "In Progress",
  blockers: "",
};

function todayInputValue() {
  return new Date().toISOString().slice(0, 10);
}

export default function DailyStandupPage() {
  const toast = useToast();
  const form = useForm<z.infer<typeof schema>>({
    resolver: zodResolver(schema),
    defaultValues: {
      date: todayInputValue(),
      tasks: [{ ...emptyTask }],
    },
  });
  const tasks = useFieldArray({ control: form.control, name: "tasks" });

  const today = useQuery({
    queryKey: ["my-standup-today"],
    queryFn: async () =>
      (await api.get<{ submitted: boolean }>("/standups/mine/today")).data,
  });

  const submitStandup = useMutation({
    mutationFn: async (values: z.infer<typeof schema>) => {
      const body = new FormData();
      body.append("date", values.date);
      body.append("tasks", JSON.stringify(values.tasks));
      return (
        await api.post("/standups", body, {
          headers: { "Content-Type": "multipart/form-data" },
        })
      ).data;
    },
    onSuccess: async () => {
      toast.success("Standup report submitted successfully.");
      form.reset({ date: todayInputValue(), tasks: [{ ...emptyTask }] });
      await today.refetch();
    },
    onError: (error: any) =>
      toast.error(error.response?.data?.message ?? "Unable to submit standup"),
  });

  return (
    <AppShell
      role="USER"
      title="Daily Standup"
      description="Submit one update per working day."
    >
      <div className="grid max-w-5xl gap-6">
        {today.data?.submitted ? (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-5 text-sm font-medium text-emerald-800">
            Standup submitted for today.
          </div>
        ) : (
          <form
            className="grid gap-5 rounded-xl border border-slate-200 bg-white p-5 shadow-sm"
            onSubmit={form.handleSubmit((values) =>
              submitStandup.mutate(values),
            )}
          >
            <div className="rounded-lg border border-slate-200 bg-slate-50 p-4">
              <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-900">
                <CalendarDays size={18} className="text-teal-700" />
                Common Report Date
              </div>
              <Field label="Date" error={form.formState.errors.date?.message}>
                <DateControl
                  value={form.watch("date")}
                  onChange={(value) =>
                    form.setValue("date", value, { shouldValidate: true })
                  }
                />
              </Field>
            </div>
            <div className="grid gap-4">
              {tasks.fields.map((task, index) => (
                <div
                  key={task.id}
                  className="grid gap-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm ring-1 ring-slate-100"
                >
                  <div className="flex items-center justify-between gap-3 border-b border-slate-100 pb-3">
                    <div>
                      <div className="text-sm font-semibold text-slate-950">
                        Task {index + 1}
                      </div>
                      <div className="mt-0.5 text-xs font-medium text-slate-500">
                        Project, task details, blockers, and status
                      </div>
                    </div>
                    <IconButton
                      aria-label={`Remove task ${index + 1}`}
                      disabled={tasks.fields.length === 1}
                      onClick={() => tasks.remove(index)}
                      type="button"
                      title={`Remove task ${index + 1}`}
                      tone="red"
                    >
                      <Trash2 className="" size={16} />
                    </IconButton>
                  </div>
                  <div className="grid gap-3 md:grid-cols-2">
                    <Field
                      label="Project Name"
                      error={
                        form.formState.errors.tasks?.[index]?.projectName
                          ?.message
                      }
                    >
                      <Input {...form.register(`tasks.${index}.projectName`)} />
                    </Field>
                    <Field
                      label="Task ID"
                      error={
                        form.formState.errors.tasks?.[index]?.taskId?.message
                      }
                    >
                      <Input {...form.register(`tasks.${index}.taskId`)} />
                    </Field>
                  </div>
                  <Field
                    label="Task Description"
                    error={
                      form.formState.errors.tasks?.[index]?.taskDescription
                        ?.message
                    }
                  >
                    <Textarea
                      className="min-h-24"
                      {...form.register(`tasks.${index}.taskDescription`)}
                    />
                  </Field>
                  <div className="grid gap-3 md:grid-cols-2">
                    <Field
                      label="Time Spent"
                      error={
                        form.formState.errors.tasks?.[index]?.timeSpent?.message
                      }
                    >
                      <Input
                        type="number"
                        min={0}
                        step={0.25}
                        {...form.register(`tasks.${index}.timeSpent`)}
                      />
                    </Field>
                    <Field
                      label="Status"
                      error={
                        form.formState.errors.tasks?.[index]?.taskStatus
                          ?.message
                      }
                    >
                      <CustomSelect
                        value={form.watch(`tasks.${index}.taskStatus`)}
                        onChange={(value) =>
                          form.setValue(`tasks.${index}.taskStatus`, value, {
                            shouldValidate: true,
                          })
                        }
                        options={[
                          { label: "Not Started", value: "Not Started" },
                          { label: "In Progress", value: "In Progress" },
                          { label: "Completed", value: "Completed" },
                          { label: "Blocked", value: "Blocked" },
                        ]}
                      />
                    </Field>
                  </div>
                  <Field
                    label="Blockers"
                    error={
                      form.formState.errors.tasks?.[index]?.blockers?.message
                    }
                  >
                    <Textarea
                      className="min-h-20"
                      {...form.register(`tasks.${index}.blockers`)}
                    />
                  </Field>
                </div>
              ))}
              <SecondaryButton
                className="border-dashed border-slate-300 bg-slate-50 hover:bg-teal-50 hover:text-teal-800"
                type="button"
                onClick={() => tasks.append({ ...emptyTask })}
              >
                <Plus size={18} />
                Add Task
              </SecondaryButton>
            </div>
            <Button
              className="justify-self-start px-6"
              disabled={submitStandup.isPending}
              type="submit"
            >
              <Send size={18} />
              Submit
            </Button>
          </form>
        )}
      </div>
    </AppShell>
  );
}
