import { AppShell } from "@/components/app-shell";
import { ProfileCard } from "@/components/profile-card";

export default function AdminProfilePage() {
  return (
    <AppShell role="ADMIN" title="Profile" description="Profile details will appear here.">
      <ProfileCard />
    </AppShell>
  );
}
