"use client";

import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { Stat } from "@/components/ui";
import { api } from "@/lib/api";

type Dashboard = {
  assignedUsers: number;
  submittedToday: number;
  pendingStandups: number;
};

export default function AdminDashboard() {
  const { data } = useQuery({
    queryKey: ["dashboard", "admin"],
    queryFn: async () => (await api.get<Dashboard>("/dashboard")).data
  });

  return (
    <AppShell role="ADMIN" title="Dashboard" description="Assigned user and team report overview.">
      <div className="grid gap-6">
        <div className="grid gap-4 md:grid-cols-3">
          <Stat label="Assigned Users" value={data?.assignedUsers ?? 0} />
          <Stat label="Standups Submitted" value={data?.submittedToday ?? 0} />
          <Stat label="Pending Standups" value={data?.pendingStandups ?? 0} />
        </div>
      </div>
    </AppShell>
  );
}
