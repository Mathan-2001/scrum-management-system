"use client";

import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { AppShell } from "@/components/app-shell";
import { StandupsTable } from "@/components/standups-table";
import { CustomSelect, DateControl, Field, Input } from "@/components/ui";
import { api } from "@/lib/api";
import { StandupRecord } from "@/lib/types";

export default function AdminStandupsPage() {
  const [filters, setFilters] = useState({ date: "", employee: "", status: "" });
  const params = useMemo(
    () => Object.fromEntries(Object.entries(filters).filter(([, value]) => value)),
    [filters]
  );

  const { data = [] } = useQuery({
    queryKey: ["admin-standups", params],
    queryFn: async () => (await api.get<StandupRecord[]>("/standups", { params })).data
  });

  return (
    <AppShell role="ADMIN" title="Team Reports" description="Daily standup reports for your team.">
      <div className="grid gap-6">
        <div className="app-surface grid gap-3 rounded-lg p-4 md:grid-cols-3">
          <Field label="Date">
            <DateControl value={filters.date} onChange={(date) => setFilters((current) => ({ ...current, date }))} />
          </Field>
          <Field label="Employee">
            <Input value={filters.employee} onChange={(event) => setFilters((current) => ({ ...current, employee: event.target.value }))} placeholder="EMP101" />
          </Field>
          <Field label="Status">
            <CustomSelect
              value={filters.status}
              onChange={(status) => setFilters((current) => ({ ...current, status }))}
              options={[{ label: "All Statuses", value: "" }, { label: "Submitted", value: "SUBMITTED" }, { label: "Pending", value: "PENDING" }]}
            />
          </Field>
        </div>
        <StandupsTable data={data} />
      </div>
    </AppShell>
  );
}
