"use client";

import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/app-shell";
import { StatusBadge } from "@/components/ui";
import { api } from "@/lib/api";
import { UserRecord } from "@/lib/types";

export default function AssignedUsersPage() {
  const { data = [] } = useQuery({
    queryKey: ["assigned-users"],
    queryFn: async () => (await api.get<UserRecord[]>("/users")).data
  });

  return (
    <AppShell role="ADMIN" title="Assigned Users" description="Users currently assigned to you.">
      <div className="grid gap-6">
        <div className="app-table-shell thin-scrollbar max-h-[620px] overflow-auto rounded-lg">
          <table className="w-full min-w-[720px] border-separate border-spacing-0 text-left text-sm">
            <thead className="sticky top-0 z-20 bg-[#0f172a] text-xs uppercase tracking-wide text-white shadow-sm">
              <tr>
                <th className="px-5 py-4 font-bold">Employee ID</th>
                <th className="px-5 py-4 font-bold">Name</th>
                <th className="px-5 py-4 font-bold">Email</th>
                <th className="px-5 py-4 font-bold">Status</th>
              </tr>
            </thead>
            <tbody className="bg-white">
              {data.length === 0 ? (
                <tr>
                  <td className="px-5 py-10 text-center text-slate-500" colSpan={4}>No assigned users found.</td>
                </tr>
              ) : data.map((user) => (
                <tr key={user.id} className="text-slate-800 transition hover:bg-slate-50">
                  <td className="border-b border-slate-200 px-5 py-4 text-slate-950">{user.employeeId}</td>
                  <td className="border-b border-slate-200 px-5 py-4 text-slate-950">{user.name}</td>
                  <td className="border-b border-slate-200 px-5 py-4">{user.email}</td>
                  <td className="border-b border-slate-200 px-5 py-4">
                    <StatusBadge>{user.isActive === false ? "Inactive" : "Active"}</StatusBadge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
