"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { KeyRound, Mail } from "lucide-react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { api, dashboardPath, saveSession } from "@/lib/api";
import { AuthUser } from "@/lib/types";
import { Button, Field, Input, SecondaryButton } from "@/components/ui";
import { useToast } from "@/components/toast";
import { ThemeSwitcher } from "@/components/app-shell";

const emailSchema = z.object({ email: z.string().email("Enter a valid email") });
const otpSchema = z.object({ otp: z.string().regex(/^\d{6}$/, "Enter 6 digits") });

export default function LoginPage() {
  const router = useRouter();
  const [step, setStep] = useState<"email" | "otp">("email");
  const [email, setEmail] = useState("");
  const [cooldown, setCooldown] = useState(0);
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  const emailForm = useForm<z.infer<typeof emailSchema>>({ resolver: zodResolver(emailSchema), defaultValues: { email: "" } });
  const otpForm = useForm<z.infer<typeof otpSchema>>({ resolver: zodResolver(otpSchema), defaultValues: { otp: "" } });

  async function requestOtp(values: z.infer<typeof emailSchema>) {
    setLoading(true);
    try {
      await api.post("/auth/request-otp", values);
      setEmail(values.email);
      setStep("otp");
      setCooldown(60);
      toast.success("OTP sent to your registered email.");
      const timer = setInterval(() => {
        setCooldown((current) => {
          if (current <= 1) clearInterval(timer);
          return Math.max(current - 1, 0);
        });
      }, 1000);
    } catch (error: any) {
      toast.error(error.response?.data?.message ?? "Unable to send OTP");
    } finally {
      setLoading(false);
    }
  }

  async function verifyOtp(values: z.infer<typeof otpSchema>) {
    setLoading(true);
    try {
      const { data } = await api.post<{ token: string; user: AuthUser }>("/auth/verify-otp", { email, otp: values.otp });
      saveSession(data.token, data.user);
      toast.success("Login successful.");
      router.push(dashboardPath(data.user.role));
    } catch (error: any) {
      toast.error(error.response?.data?.message ?? "Invalid OTP");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-app p-4">
      <div className="fixed right-4 top-4 z-10">
        <ThemeSwitcher />
      </div>
      <section className="w-full max-w-md rounded-lg border border-border bg-panel p-6 shadow-sm">
        <div className="mb-6">
          <div className="inline-flex h-11 w-11 items-center justify-center rounded-md bg-teal-50 text-brand shadow-sm">
            {step === "email" ? <Mail size={22} /> : <KeyRound size={22} />}
          </div>
          <h1 className="mt-4 text-2xl font-semibold text-ink">Scrum Management System</h1>
          <p className="mt-2 text-sm text-muted">Login with your registered email and a secure 6-digit OTP.</p>
        </div>

        {step === "email" ? (
          <form className="grid gap-4" onSubmit={emailForm.handleSubmit(requestOtp)}>
            <Field label="Email" error={emailForm.formState.errors.email?.message}>
              <Input type="email" placeholder="name@company.com" {...emailForm.register("email")} />
            </Field>
            <Button disabled={loading} type="submit">
              Send OTP
            </Button>
          </form>
        ) : (
          <form className="grid gap-4" onSubmit={otpForm.handleSubmit(verifyOtp)}>
            <Field label="OTP" error={otpForm.formState.errors.otp?.message}>
              <Input inputMode="numeric" maxLength={6} placeholder="123456" {...otpForm.register("otp")} />
            </Field>
            <Button disabled={loading} type="submit">
              Verify OTP
            </Button>
            <SecondaryButton type="button" disabled={cooldown > 0 || loading} onClick={() => requestOtp({ email })}>
              {cooldown > 0 ? `Resend in ${cooldown}s` : "Request New OTP"}
            </SecondaryButton>
          </form>
        )}
      </section>
    </main>
  );
}
