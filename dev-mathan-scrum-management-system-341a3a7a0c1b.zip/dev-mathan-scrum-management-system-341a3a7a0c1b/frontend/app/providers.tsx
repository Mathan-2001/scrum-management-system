"use client";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { ToastProvider } from "@/components/toast";

export type ThemeMode = "atelier" | "focus" | "dusk";

type ThemeContextValue = {
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
};

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);
const themeKey = "scrum-ui-theme";

function readStoredTheme(): ThemeMode {
  if (typeof window === "undefined") return "atelier";
  const stored = window.localStorage.getItem(themeKey);
  return stored === "focus" || stored === "dusk" || stored === "atelier" ? stored : "atelier";
}

export function Providers({ children }: { children: React.ReactNode }) {
  const [client] = useState(() => new QueryClient());
  const [theme, setThemeState] = useState<ThemeMode>("atelier");

  useEffect(() => {
    setThemeState(readStoredTheme());
  }, []);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    window.localStorage.setItem(themeKey, theme);
  }, [theme]);

  const value = useMemo(
    () => ({
      theme,
      setTheme: setThemeState
    }),
    [theme]
  );

  return (
    <QueryClientProvider client={client}>
      <ThemeContext.Provider value={value}>
        <ToastProvider>{children}</ToastProvider>
      </ThemeContext.Provider>
    </QueryClientProvider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used inside Providers");
  return context;
}
