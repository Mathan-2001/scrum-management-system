export type Role = "SUPER_ADMIN" | "ADMIN" | "USER";

export type AuthUser = {
  id: string;
  name: string;
  email: string;
  employeeId: string;
  role: Role;
};

export type UserRecord = {
  id: string;
  name: string;
  employeeId: string;
  email: string;
  role: Role;
  isActive?: boolean;
  createdAt: string;
};

export type StandupRecord = {
  id: string;
  date: string;
  tasks: StandupTask[];
  attachmentName?: string;
  submittedAt: string;
  status: "SUBMITTED" | "PENDING";
  user: {
    name: string;
    employeeId: string;
    role: Role;
  };
};

export type StandupTask = {
  projectName: string;
  taskId: string;
  taskDescription: string;
  timeSpent: number;
  taskStatus: string;
  blockers?: string;
};
