"use client";

import clsx from "clsx";
import {
  CalendarDays,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import {
  ButtonHTMLAttributes,
  InputHTMLAttributes,
  SelectHTMLAttributes,
  TextareaHTMLAttributes,
  useEffect,
  useRef,
  useState,
} from "react";

export function Button({
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={clsx(
        "focus-ring inline-flex h-10 items-center justify-center gap-2 rounded-md bg-teal-700 px-4 text-sm font-semibold text-white shadow-sm shadow-teal-900/10 transition hover:bg-teal-800 disabled:cursor-not-allowed disabled:opacity-60",
        className,
      )}
      {...props}
    />
  );
}

export function SecondaryButton({
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={clsx(
        "focus-ring inline-flex h-10 items-center justify-center gap-2 rounded-md border border-border bg-panel px-4 text-sm font-semibold text-ink transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-60",
        className,
      )}
      {...props}
    />
  );
}

export function IconButton({
  className,
  tone = "slate",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  tone?: "slate" | "teal" | "red";
}) {
  const tones = {
    slate:
      "border-border bg-panel text-ink hover:bg-slate-50 disabled:bg-slate-100 disabled:text-slate-400",
    teal: "border-teal-300 bg-teal-50 text-teal-800 hover:border-teal-400 hover:bg-teal-100 hover:text-teal-950 disabled:bg-slate-100 disabled:text-slate-400",
    red: "border-red-300 bg-red-50 text-red-800 hover:border-red-400 hover:bg-red-100 hover:text-red-950 disabled:bg-slate-100 disabled:text-slate-400",
  };

  return (
    <button
      className={clsx(
        "focus-ring inline-flex h-8 w-8 items-center justify-center rounded-md border shadow-sm transition disabled:cursor-not-allowed disabled:opacity-60",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}

export function Input({
  className,
  ...props
}: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={clsx(
        "focus-ring h-10 w-full rounded-md border border-border bg-panel px-3 text-sm text-ink placeholder:text-slate-400 shadow-[inset_0_1px_0_rgba(15,23,42,0.03)] transition hover:border-slate-300",
        className,
      )}
      {...props}
    />
  );
}

export function Textarea({
  className,
  ...props
}: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <textarea
      className={clsx(
        "focus-ring min-h-28 w-full rounded-md border border-border bg-panel px-3 py-2 text-sm text-ink shadow-[inset_0_1px_0_rgba(15,23,42,0.03)] transition hover:border-slate-300",
        className,
      )}
      {...props}
    />
  );
}

export function Select({
  className,
  ...props
}: SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select
      className={clsx(
        "focus-ring h-10 w-full rounded-md border border-border bg-panel px-3 text-sm text-ink",
        className,
      )}
      {...props}
    />
  );
}

export function DateControl({
  className,
  value,
  onChange,
}: {
  className?: string;
  value: string;
  onChange: (value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const selectedDate = value ? new Date(`${value}T00:00:00`) : new Date();
  const [visibleMonth, setVisibleMonth] = useState(
    () => new Date(selectedDate.getFullYear(), selectedDate.getMonth(), 1),
  );

  useEffect(() => {
    function onPointerDown(event: MouseEvent) {
      if (!ref.current?.contains(event.target as Node)) setOpen(false);
    }

    document.addEventListener("mousedown", onPointerDown);
    return () => document.removeEventListener("mousedown", onPointerDown);
  }, []);

  const year = visibleMonth.getFullYear();
  const month = visibleMonth.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const days = Array.from({ length: firstDay + daysInMonth }, (_, index) =>
    index < firstDay ? undefined : index - firstDay + 1,
  );

  function formatDisplay(dateValue: string) {
    if (!dateValue) return "Select date";
    const [yyyy, mm, dd] = dateValue.split("-");
    return `${dd}-${mm}-${yyyy}`;
  }

  function toValue(day: number) {
    const mm = String(month + 1).padStart(2, "0");
    const dd = String(day).padStart(2, "0");
    return `${year}-${mm}-${dd}`;
  }

  return (
    <div ref={ref} className="relative">
      <button
        className={clsx(
          "focus-ring flex h-10 w-full items-center justify-between gap-2 rounded-md border border-border bg-panel px-3 text-left text-sm text-ink shadow-[inset_0_1px_0_rgba(15,23,42,0.03)] transition hover:border-slate-400",
          className,
        )}
        onClick={() => setOpen((current) => !current)}
        type="button"
      >
        <span className="flex items-center gap-2">
          <CalendarDays size={17} className="shrink-0 text-teal-700" />
          {formatDisplay(value)}
        </span>
        <ChevronDown
          className={clsx(
            "shrink-0 text-slate-500 transition",
            open && "rotate-180",
          )}
          size={16}
        />
      </button>
      {open ? (
        <div className="absolute z-40 mt-2 w-72 rounded-lg border border-border bg-panel p-3 shadow-xl">
          <div className="mb-3 flex items-center justify-between">
            <button
              className="rounded-md p-2 text-muted hover:bg-slate-50 hover:text-ink"
              onClick={() => setVisibleMonth(new Date(year, month - 1, 1))}
              type="button"
            >
              <ChevronLeft size={17} />
            </button>
            <div className="text-sm font-semibold text-ink">
              {visibleMonth.toLocaleString(undefined, {
                month: "long",
                year: "numeric",
              })}
            </div>
            <button
              className="rounded-md p-2 text-muted hover:bg-slate-50 hover:text-ink"
              onClick={() => setVisibleMonth(new Date(year, month + 1, 1))}
              type="button"
            >
              <ChevronRight size={17} />
            </button>
          </div>
          <div className="grid grid-cols-7 gap-1 text-center text-xs font-medium text-muted">
            {["S", "M", "T", "W", "T", "F", "S"].map((day) => (
              <div key={day} className="py-1">
                {day}
              </div>
            ))}
          </div>
          <div className="mt-1 grid grid-cols-7 gap-1">
            {days.map((day, index) => {
              const dayValue = day ? toValue(day) : "";
              return day ? (
                <button
                  key={dayValue}
                  className={clsx(
                    "h-8 rounded-md text-sm transition",
                    dayValue === value
                      ? "bg-teal-700 font-semibold text-white"
                      : "text-ink hover:bg-teal-50 hover:text-teal-800",
                  )}
                  onClick={() => {
                    onChange(dayValue);
                    setOpen(false);
                  }}
                  type="button"
                >
                  {day}
                </button>
              ) : (
                <div key={`empty-${index}`} />
              );
            })}
          </div>
        </div>
      ) : null}
    </div>
  );
}

export function CustomSelect({
  options,
  value,
  onChange,
  placeholder = "Select",
  className,
}: {
  options: { label: string; value: string }[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const selected = options.find((option) => option.value === value);

  useEffect(() => {
    function onPointerDown(event: MouseEvent) {
      if (!ref.current?.contains(event.target as Node)) setOpen(false);
    }

    document.addEventListener("mousedown", onPointerDown);
    return () => document.removeEventListener("mousedown", onPointerDown);
  }, []);

  return (
    <div ref={ref} className={clsx("relative", className)}>
      <button
        className="focus-ring flex h-10 w-full items-center justify-between gap-3 rounded-md border border-border bg-panel px-3 text-left text-sm font-medium text-ink shadow-[inset_0_1px_0_rgba(15,23,42,0.03)] transition hover:border-slate-400"
        onClick={() => setOpen((current) => !current)}
        type="button"
      >
        <span className={selected ? "" : "text-slate-400"}>
          {selected?.label ?? placeholder}
        </span>
        <ChevronDown
          className={clsx(
            "shrink-0 text-slate-500 transition",
            open && "rotate-180",
          )}
          size={17}
        />
      </button>
      {open ? (
        <div className="thin-scrollbar absolute z-30 mt-2 max-h-64 w-full overflow-auto rounded-lg border border-border bg-panel p-1 shadow-xl">
          {options.map((option) => (
            <button
              key={option.value}
              className={clsx(
                "flex w-full items-center justify-between rounded-md px-3 py-2 text-left text-sm transition",
                option.value === value
                  ? "bg-slate-900 text-white"
                  : "text-ink hover:bg-slate-50",
              )}
              onClick={() => {
                onChange(option.value);
                setOpen(false);
              }}
              type="button"
            >
              {option.label}
              {option.value === value ? <Check size={15} /> : null}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <label className="grid gap-1.5 text-sm font-medium text-ink">
      <span>{label}</span>
      {children}
      {error ? (
        <span className="text-xs font-medium text-red-600">{error}</span>
      ) : null}
    </label>
  );
}

export function PageHeader({
  title,
  description,
  actions,
}: {
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-4">
      <div>
        <h2 className="text-2xl font-bold tracking-tight text-ink">
          {title}
        </h2>
        {description ? (
          <p className="mt-1 text-sm font-medium text-muted">
            {description}
          </p>
        ) : null}
      </div>
      {actions ? (
        <div className="flex items-center gap-2">{actions}</div>
      ) : null}
    </div>
  );
}

export function StatusBadge({
  children,
  tone = "green",
}: {
  children: React.ReactNode;
  tone?: "green" | "blue" | "amber" | "slate";
}) {
  const tones = {
    green: "border-emerald-200 bg-emerald-50 text-emerald-700",
    blue: "border-indigo-200 bg-indigo-50 text-indigo-700",
    amber: "border-amber-200 bg-amber-50 text-amber-800",
    slate: "border-slate-200 bg-slate-50 text-slate-700",
  };

  return (
    <span
      className={clsx(
        "inline-flex whitespace-nowrap rounded-md border px-2.5 py-1 text-xs font-medium leading-4",
        tones[tone],
      )}
    >
      {children}
    </span>
  );
}

export function AppTooltip({
  children,
  content,
}: {
  children: React.ReactNode;
  content: string;
}) {
  return (
    <span className="group/tooltip relative inline-block max-w-full">
      {children}
      <span className="pointer-events-none absolute left-0 top-full z-40 mt-2 hidden w-80 max-w-[70vw] rounded-md border border-slate-700 bg-[#0f172a] px-3 py-2 text-xs font-medium leading-5 text-white shadow-xl group-hover/tooltip:block">
        {content}
      </span>
    </span>
  );
}

export function Stat({
  label,
  value,
}: {
  label: string;
  value: string | number;
}) {
  return (
    <div className="rounded-lg border border-border bg-panel p-5 shadow-sm">
      <div className="text-xs font-semibold uppercase tracking-wide text-muted">
        {label}
      </div>
      <div className="mt-2 text-3xl font-bold text-ink">{value}</div>
    </div>
  );
}
