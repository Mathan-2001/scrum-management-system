"use client";

import { getSessionUser } from "@/lib/api";
import { StatusBadge } from "@/components/ui";

export function ProfileCard() {
  const user = getSessionUser();
  const initials = (user?.name ?? "User")
    .split(" ")
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  return (
    <section className="app-surface rounded-lg p-6">
      <div className="flex flex-wrap items-center gap-5 border-b border-border pb-5">
        <div className="grid h-20 w-20 place-items-center rounded-lg bg-teal-50 text-2xl font-bold text-teal-700 ring-1 ring-inset ring-teal-100">
          {initials}
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-950">{user?.name ?? "-"}</h2>
          <p className="mt-1 text-sm font-medium text-slate-500">{user?.email ?? "-"}</p>
        </div>
      </div>
      <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-5">
        <ProfileItem label="Employee ID" value={user?.employeeId ?? "-"} />
        <ProfileItem label="Name" value={user?.name ?? "-"} />
        <ProfileItem label="Role" value={user?.role.replace("_", " ") ?? "-"} />
        <ProfileItem label="Email" value={user?.email ?? "-"} />
        <div className="rounded-lg border border-border bg-slate-50 p-4">
          <div className="text-xs font-medium uppercase tracking-wide text-slate-500">Status</div>
          <div className="mt-2"><StatusBadge>Active</StatusBadge></div>
        </div>
      </div>
    </section>
  );
}

function ProfileItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-border bg-slate-50 p-4">
      <div className="text-xs font-medium uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mt-2 break-words text-sm text-slate-950">{value}</div>
    </div>
  );
}
