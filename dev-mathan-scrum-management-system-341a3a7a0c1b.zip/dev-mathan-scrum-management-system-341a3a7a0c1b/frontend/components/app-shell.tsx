"use client";

import { BarChart3, Bell, ClipboardList, FileClock, Home, LogOut, Moon, Palette, Settings, SunMedium, User, Users, Workflow, Zap } from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { clearSession, getSessionUser } from "@/lib/api";
import { Role } from "@/lib/types";
import clsx from "clsx";
import { ThemeMode, useTheme } from "@/app/providers";

const navByRole: Record<Role, { href: string; label: string; icon: React.ElementType }[]> = {
  SUPER_ADMIN: [
    { href: "/super-admin/dashboard", label: "Dashboard", icon: Home },
    { href: "/super-admin/users", label: "Users", icon: Users },
    { href: "/super-admin/standups", label: "Reports", icon: BarChart3 },
    { href: "/super-admin/settings", label: "Settings", icon: Settings },
    { href: "/super-admin/profile", label: "Profile", icon: User }
  ],
  ADMIN: [
    { href: "/admin/dashboard", label: "Dashboard", icon: Home },
    { href: "/admin/users", label: "Assigned Users", icon: Users },
    { href: "/admin/standups", label: "Team Reports", icon: BarChart3 },
    { href: "/admin/profile", label: "Profile", icon: User }
  ],
  USER: [
    { href: "/user/dashboard", label: "Dashboard", icon: Home },
    { href: "/user/standup", label: "Daily Standup", icon: ClipboardList },
    { href: "/user/history", label: "Report History", icon: FileClock },
    { href: "/user/profile", label: "Profile", icon: User },
    { href: "/user/notifications", label: "Notifications", icon: Bell }
  ]
};

const themes: { value: ThemeMode; label: string; icon: React.ElementType }[] = [
  { value: "atelier", label: "Atelier", icon: SunMedium },
  { value: "focus", label: "Focus", icon: Moon },
  { value: "dusk", label: "Dusk", icon: Zap }
];

export function ThemeSwitcher({ compact = false }: { compact?: boolean }) {
  const { theme, setTheme } = useTheme();

  return (
    <div className="flex h-10 items-center gap-1 rounded-md border border-border bg-panel p-1 shadow-sm" aria-label="Theme selector">
      {!compact ? <Palette size={16} className="ml-2 text-muted" /> : null}
      {themes.map((item) => {
        const Icon = item.icon;
        const active = theme === item.value;

        return (
          <button
            key={item.value}
            className={clsx(
              "focus-ring inline-flex h-8 items-center justify-center gap-1.5 rounded px-2 text-xs font-semibold transition",
              active ? "bg-brand text-white shadow-sm" : "text-muted hover:bg-slate-50 hover:text-ink",
              compact && "w-8 px-0"
            )}
            onClick={() => setTheme(item.value)}
            title={`${item.label} theme`}
            type="button"
          >
            <Icon size={15} />
            {!compact ? item.label : <span className="sr-only">{item.label}</span>}
          </button>
        );
      })}
    </div>
  );
}

export function AppShell({
  actions,
  children,
  description,
  role,
  title
}: {
  actions?: React.ReactNode;
  children: React.ReactNode;
  description?: string;
  role: Role;
  title?: string;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const user = getSessionUser();

  function logout() {
    clearSession();
    router.push("/");
  }

  return (
    <div className="min-h-screen bg-app">
      <aside className="fixed inset-y-0 left-0 hidden w-64 border-r border-border bg-[#0f172a] text-white lg:block">
        <div className="border-b border-white/10 px-4 py-5">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-brand text-white shadow-lg">
              <Workflow size={23} />
            </div>
            <div className="min-w-0">
              <div className="truncate text-lg font-bold tracking-tight">Scrum SMS</div>
              <div className="mt-0.5 truncate text-xs font-medium uppercase tracking-wide" style={{ color: "var(--nav-muted)" }}>{user?.role.replace("_", " ") ?? "Workspace"}</div>
            </div>
          </div>
        </div>
        <nav className="grid gap-1 p-3">
          {navByRole[role].map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={clsx(
                  "flex h-10 items-center gap-3 rounded-md px-3 text-sm font-medium transition",
                  pathname === item.href ? "text-white ring-1 ring-inset ring-white/10" : "hover:bg-white/5 hover:text-white"
                )}
                style={{ background: pathname === item.href ? "var(--nav-active)" : undefined, color: pathname === item.href ? "#fff" : "var(--nav-muted)" }}
              >
                <Icon size={18} />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="absolute bottom-4 left-3 right-3 grid gap-3">
          <ThemeSwitcher compact />
          <button onClick={logout} className="flex h-10 items-center gap-3 rounded-md px-3 text-sm font-medium transition hover:bg-white/5 hover:text-white" style={{ color: "var(--nav-muted)" }}>
            <LogOut size={18} />
            Logout
          </button>
        </div>
      </aside>
      <main className="lg:pl-64">
        <header className="sticky top-0 z-10 border-b border-border bg-panel px-4 py-5 shadow-sm backdrop-blur lg:px-8">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold tracking-tight text-ink">{title ?? user?.role.replace("_", " ")}</h1>
              {description ? <p className="mt-1 text-sm font-medium text-muted">{description}</p> : null}
            </div>
            <div className="flex items-center gap-2">
              {actions}
              <ThemeSwitcher />
              <button onClick={logout} className="inline-flex h-10 items-center gap-2 rounded-md border border-border bg-panel px-3 text-sm font-semibold text-ink lg:hidden">
                <LogOut size={18} />
                Logout
              </button>
            </div>
          </div>
        </header>
        <div className="p-4 lg:p-8">{children}</div>
      </main>
    </div>
  );
}
