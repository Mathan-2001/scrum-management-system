"use client";

import { AlertCircle, CheckCircle2, Info, TriangleAlert, X } from "lucide-react";
import { createContext, useCallback, useContext, useMemo, useState } from "react";
import clsx from "clsx";

type ToastType = "success" | "error" | "warning" | "info";

type Toast = {
  id: string;
  type: ToastType;
  message: string;
};

type ToastContextValue = {
  success: (message: string) => void;
  error: (message: string) => void;
  warning: (message: string) => void;
  info: (message: string) => void;
};

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

const toastStyles: Record<ToastType, { icon: React.ElementType; className: string; title: string }> = {
  success: { icon: CheckCircle2, className: "app-toast-success", title: "Success" },
  error: { icon: AlertCircle, className: "app-toast-error", title: "Error" },
  warning: { icon: TriangleAlert, className: "app-toast-warning", title: "Warning" },
  info: { icon: Info, className: "app-toast-info", title: "Info" }
};

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const remove = useCallback((id: string) => {
    setToasts((current) => current.filter((toast) => toast.id !== id));
  }, []);

  const show = useCallback((type: ToastType, message: string) => {
    const id = crypto.randomUUID();
    setToasts((current) => [...current, { id, type, message }]);
    window.setTimeout(() => remove(id), 4500);
  }, [remove]);

  const value = useMemo<ToastContextValue>(() => ({
    success: (message) => show("success", message),
    error: (message) => show("error", message),
    warning: (message) => show("warning", message),
    info: (message) => show("info", message)
  }), [show]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="fixed bottom-4 right-4 z-50 grid w-[min(360px,calc(100vw-2rem))] gap-3">
        {toasts.map((toast) => {
          const style = toastStyles[toast.type];
          const Icon = style.icon;

          return (
            <div key={toast.id} className={clsx("app-toast rounded-lg border p-4 shadow-lg", style.className)}>
              <div className="flex items-start gap-3">
                <Icon className="mt-0.5 shrink-0" size={19} />
                <div className="min-w-0 flex-1">
                  <div className="text-sm font-semibold">{style.title}</div>
                  <div className="mt-0.5 text-sm leading-5">{toast.message}</div>
                </div>
                <button className="rounded p-1 opacity-70 hover:bg-white/60 hover:opacity-100" onClick={() => remove(toast.id)} type="button">
                  <X size={16} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) throw new Error("useToast must be used inside ToastProvider");
  return context;
}
