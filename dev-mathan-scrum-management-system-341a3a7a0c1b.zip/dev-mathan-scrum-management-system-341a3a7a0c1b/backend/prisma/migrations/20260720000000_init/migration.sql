CREATE TYPE "Role" AS ENUM ('SUPER_ADMIN', 'ADMIN', 'USER');

CREATE TYPE "StandupStatus" AS ENUM ('SUBMITTED', 'PENDING');

CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "employeeId" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "role" "Role" NOT NULL,
    "passwordHash" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "adminId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "Otp" (
    "id" TEXT NOT NULL,
    "codeHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "usedAt" TIMESTAMP(3),
    "userId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "Otp_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "Standup" (
    "id" TEXT NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "attachmentName" TEXT,
    "attachmentPath" TEXT,
    "attachmentMimeType" TEXT,
    "status" "StandupStatus" NOT NULL DEFAULT 'SUBMITTED',
    "submittedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "userId" TEXT NOT NULL,

    CONSTRAINT "Standup_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "StandupTask" (
    "id" TEXT NOT NULL,
    "standupId" TEXT NOT NULL,
    "order" INTEGER NOT NULL,
    "projectName" TEXT NOT NULL,
    "taskId" TEXT NOT NULL,
    "taskDescription" TEXT NOT NULL,
    "timeSpent" DOUBLE PRECISION NOT NULL,
    "taskStatus" TEXT NOT NULL,
    "blockers" TEXT,

    CONSTRAINT "StandupTask_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "User_employeeId_key" ON "User"("employeeId");
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");
CREATE INDEX "Otp_userId_usedAt_createdAt_idx" ON "Otp"("userId", "usedAt", "createdAt");
CREATE UNIQUE INDEX "Standup_userId_date_key" ON "Standup"("userId", "date");
CREATE INDEX "Standup_date_idx" ON "Standup"("date");
CREATE INDEX "Standup_status_idx" ON "Standup"("status");
CREATE INDEX "Standup_submittedAt_idx" ON "Standup"("submittedAt");
CREATE INDEX "StandupTask_standupId_order_idx" ON "StandupTask"("standupId", "order");

ALTER TABLE "User" ADD CONSTRAINT "User_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "Otp" ADD CONSTRAINT "Otp_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Standup" ADD CONSTRAINT "Standup_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "StandupTask" ADD CONSTRAINT "StandupTask_standupId_fkey" FOREIGN KEY ("standupId") REFERENCES "Standup"("id") ON DELETE CASCADE ON UPDATE CASCADE;
