import cors from "cors";
import express from "express";
import { config } from "./config.js";
import "./types.js";
import authRoutes from "./routes/auth.js";
import dashboardRoutes from "./routes/dashboard.js";
import standupRoutes from "./routes/standups.js";
import userRoutes from "./routes/users.js";

const app = express();

app.use(
  cors({
    origin(origin, callback) {
      if (!origin || config.frontendUrls.includes(origin)) {
        callback(null, true);
        return;
      }

      callback(new Error(`Origin ${origin} is not allowed by CORS`));
    }
  })
);
app.use(express.json());

app.get("/health", (_req, res) => res.json({ ok: true }));
app.use("/auth", authRoutes);
app.use("/dashboard", dashboardRoutes);
app.use("/users", userRoutes);
app.use("/standups", standupRoutes);

app.use((error: unknown, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error(error);

  return res.status(500).json({ message: "Internal server error" });
});

const server = app.listen(config.port, () => {
  console.log(`SMS backend running on http://localhost:${config.port}`);
});

server.on("error", (error: NodeJS.ErrnoException) => {
  if (error.code === "EADDRINUSE") {
    console.error(`Port ${config.port} is already in use. Stop the existing backend process or set PORT to another value in backend/.env.`);
    process.exit(1);
  }

  throw error;
});
