import dotenv from "dotenv";
import path from "node:path";

dotenv.config();
dotenv.config({ path: path.resolve(process.cwd(), "backend/.env") });

function parseFrontendUrls() {
  const raw = [
    process.env.FRONTEND_URL,
    process.env.FRONTEND_URLS,
    "http://localhost:3000,http://localhost:3001",
  ]
    .filter(Boolean)
    .join(",");

  const urls = raw
    .split(",")
    .map((url) => url.trim())
    .filter(Boolean);

  return Array.from(new Set(urls));
}

export const config = {
  port: Number(process.env.PORT ?? 4000),
  jwtSecret: process.env.JWT_SECRET ?? "dev-secret",
  frontendUrl: process.env.FRONTEND_URL ?? "http://localhost:3000",
  frontendUrls: parseFrontendUrls(),
  smtp: {
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT ?? 587),
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
    from:
      process.env.SMTP_FROM ?? "Scrum Management System <no-reply@scrum.local>",
  },
};
