import { Role } from "./domain.js";

export type JwtUser = {
  id: string;
  email: string;
  role: Role;
  name: string;
};

declare global {
  namespace Express {
    interface Request {
      user?: JwtUser;
    }
  }
}
