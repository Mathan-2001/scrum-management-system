import { Router } from "express";
import { Role } from "../domain.js";
import { requireAuth } from "../middleware/auth.js";
import { asyncHandler } from "../middleware/async-handler.js";
import { store } from "../store.js";

const router = Router();

function startOfToday() {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return date;
}

router.get("/", requireAuth, asyncHandler(async (req, res) => {
  const today = startOfToday();

  if (req.user!.role === Role.SUPER_ADMIN) {
    const [totalUsers, totalAdmins, submittedToday] = await Promise.all([
      store.countUsers({ role: Role.USER }),
      store.countUsers({ role: Role.ADMIN }),
      store.countStandupsForDate(today)
    ]);

    return res.json({
      totalUsers,
      totalAdmins,
      submittedToday,
      pendingStandups: Math.max(totalUsers - submittedToday, 0),
      recentActivities: [`${submittedToday} standups submitted today`]
    });
  }

  if (req.user!.role === Role.ADMIN) {
    const [assignedUsers, submittedToday] = await Promise.all([
      store.countUsers({ adminId: req.user!.id }),
      store.countStandupsForDate(today, req.user!.id)
    ]);

    return res.json({
      assignedUsers,
      submittedToday,
      pendingStandups: Math.max(assignedUsers - submittedToday, 0)
    });
  }

  const standup = await store.findStandupForDate(req.user!.id, today);

  return res.json({
    welcomeName: req.user!.name,
    todayStatus: standup ? "Standup Submitted" : "Pending",
    pendingTasks: standup ? 0 : 1,
    completedTasks: standup ? 1 : 0,
    currentSprint: "Current Sprint"
  });
}));

export default router;
