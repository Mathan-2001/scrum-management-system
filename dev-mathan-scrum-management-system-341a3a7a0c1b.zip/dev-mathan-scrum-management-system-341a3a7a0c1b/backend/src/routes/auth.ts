import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { sendOtpEmail } from "../email.js";
import { signSession } from "../middleware/auth.js";
import { asyncHandler } from "../middleware/async-handler.js";
import { store } from "../store.js";

const router = Router();

const requestOtpSchema = z.object({
  email: z.string().email()
});

const verifyOtpSchema = z.object({
  email: z.string().email(),
  otp: z.string().regex(/^\d{6}$/)
});

function generateOtp() {
  return crypto.randomInt(100000, 1000000).toString();
}

router.post("/request-otp", asyncHandler(async (req, res) => {
  const parsed = requestOtpSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid email" });

  const user = await store.findUserByEmail(parsed.data.email);
  if (!user || !user.isActive) return res.status(404).json({ message: "Email not found" });

  const latestOtp = await store.latestOpenOtp(user.id);

  if (latestOtp && Date.now() - new Date(latestOtp.createdAt).getTime() < 60_000) {
    return res.status(429).json({ message: "Please wait 60 seconds before requesting a new OTP" });
  }

  const otp = generateOtp();
  const codeHash = await bcrypt.hash(otp, 10);

  await store.createOtp(user.id, codeHash, new Date(Date.now() + 5 * 60_000));

  await sendOtpEmail(user.email, otp);
  return res.json({ message: "OTP sent" });
}));

router.post("/verify-otp", asyncHandler(async (req, res) => {
  const parsed = verifyOtpSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid OTP" });

  const user = await store.findUserByEmail(parsed.data.email);
  if (!user || !user.isActive) return res.status(404).json({ message: "Email not found" });

  const otp = await store.latestOpenOtp(user.id);

  if (!otp) return res.status(400).json({ message: "Invalid OTP" });
  if (new Date(otp.expiresAt).getTime() < Date.now()) return res.status(400).json({ message: "OTP Expired" });

  const isValid = await bcrypt.compare(parsed.data.otp, otp.codeHash);
  if (!isValid) return res.status(400).json({ message: "Invalid OTP" });

  await store.markOtpUsed(otp.id);

  const token = signSession({
    id: user.id,
    email: user.email,
    role: user.role,
    name: user.name
  });

  return res.json({
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      employeeId: user.employeeId
    }
  });
}));

export default router;
