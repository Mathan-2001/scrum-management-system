import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import { Router } from "express";
import { z } from "zod";
import { Role } from "../domain.js";
import { sendWelcomeEmail } from "../email.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { asyncHandler } from "../middleware/async-handler.js";
import { store } from "../store.js";

const router = Router();

const createUserSchema = z.object({
  name: z.string().min(3),
  employeeId: z.string().min(1),
  email: z.string().email(),
  role: z.nativeEnum(Role).refine((role) => role === Role.ADMIN || role === Role.USER),
  adminId: z.string().optional()
});

const updateUserSchema = z.object({
  name: z.string().min(3),
  employeeId: z.string().min(1),
  email: z.string().email(),
  role: z.nativeEnum(Role).refine((role) => role === Role.ADMIN || role === Role.USER)
});

function makeTemporaryPassword() {
  return crypto.randomBytes(8).toString("base64url");
}

router.get("/", requireAuth, requireRole(Role.SUPER_ADMIN, Role.ADMIN), asyncHandler(async (req, res) => {
  const adminId = req.user?.role === Role.ADMIN ? req.user.id : undefined;
  const users = (await store.listUsers(adminId)).map(({ passwordHash, adminId: _adminId, updatedAt, ...user }) => user);

  return res.json(users);
}));

router.post("/", requireAuth, requireRole(Role.SUPER_ADMIN), asyncHandler(async (req, res) => {
  const parsed = createUserSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid user data" });

  const existing = await store.findUserByEmailOrEmployeeId(parsed.data.email, parsed.data.employeeId);

  if (existing?.email === parsed.data.email) {
    return res.status(409).json({ message: "Email must be unique" });
  }

  if (existing?.employeeId === parsed.data.employeeId) {
    return res.status(409).json({ message: "Employee ID must be unique" });
  }

  const password = makeTemporaryPassword();
  const passwordHash = await bcrypt.hash(password, 10);

  const user = await store.createUser({
    name: parsed.data.name,
    employeeId: parsed.data.employeeId,
    email: parsed.data.email,
    role: parsed.data.role,
    adminId: parsed.data.role === Role.USER ? parsed.data.adminId : undefined,
    passwordHash
  });

  await sendWelcomeEmail({
    name: user.name,
    employeeId: user.employeeId,
    role: user.role,
    email: user.email,
    password
  });

  return res.status(201).json(user);
}));

router.patch("/:id/reset-login", requireAuth, requireRole(Role.SUPER_ADMIN), asyncHandler(async (req, res) => {
  const userId = String(req.params.id);
  const password = makeTemporaryPassword();
  const passwordHash = await bcrypt.hash(password, 10);
  const user = await store.updateUserPassword(userId, passwordHash);
  if (!user) return res.status(404).json({ message: "User not found" });

  await sendWelcomeEmail({
    name: user.name,
    employeeId: user.employeeId,
    role: user.role,
    email: user.email,
    password
  });

  return res.json({ message: "Login reset email sent" });
}));

router.patch("/:id", requireAuth, requireRole(Role.SUPER_ADMIN), asyncHandler(async (req, res) => {
  const userId = String(req.params.id);
  const parsed = updateUserSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid user data" });

  const existing = await store.findUserByEmailOrEmployeeId(parsed.data.email, parsed.data.employeeId);
  if (existing && existing.id !== userId) {
    if (existing.email === parsed.data.email) return res.status(409).json({ message: "Email must be unique" });
    if (existing.employeeId === parsed.data.employeeId) return res.status(409).json({ message: "Employee ID must be unique" });
  }

  const user = await store.updateUser(userId, parsed.data);
  if (user === undefined) return res.status(404).json({ message: "User not found" });
  if (user === false) return res.status(400).json({ message: "Super admin account cannot be edited" });

  return res.json(user);
}));

router.delete("/:id", requireAuth, requireRole(Role.SUPER_ADMIN), asyncHandler(async (req, res) => {
  const userId = String(req.params.id);
  if (userId === req.user!.id) return res.status(400).json({ message: "You cannot delete your own account" });

  const result = await store.deleteUser(userId);
  if (result === undefined) return res.status(404).json({ message: "User not found" });
  if (result === false) return res.status(400).json({ message: "Super admin account cannot be deleted" });

  return res.json({ message: "User deleted successfully" });
}));

export default router;
