import fs from "node:fs";
import path from "node:path";
import { Router } from "express";
import multer from "multer";
import { z } from "zod";
import { Role } from "../domain.js";
import { requireAuth, requireRole } from "../middleware/auth.js";
import { asyncHandler } from "../middleware/async-handler.js";
import { store } from "../store.js";

const router = Router();
const uploadDir = path.join(process.cwd(), "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = new Set([
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "image/png",
      "image/jpeg",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    ]);
    cb(null, allowed.has(file.mimetype));
  }
});

const standupSchema = z.object({
  date: z.coerce.date(),
  tasks: z.string().transform((value, ctx) => {
    try {
      const parsed = JSON.parse(value);
      const result = z.array(z.object({
        projectName: z.string().min(1),
        taskId: z.string().min(1),
        taskDescription: z.string().min(1),
        timeSpent: z.coerce.number().min(0),
        taskStatus: z.string().min(1),
        blockers: z.string().optional()
      })).min(1).safeParse(parsed);

      if (!result.success) {
        ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Invalid tasks" });
        return z.NEVER;
      }

      return result.data;
    } catch {
      ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Invalid tasks" });
      return z.NEVER;
    }
  })
});

function startOfToday() {
  const date = new Date();
  date.setHours(0, 0, 0, 0);
  return date;
}

router.post("/", requireAuth, requireRole(Role.USER), upload.single("attachment"), asyncHandler(async (req, res) => {
  const parsed = standupSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ message: "Invalid standup data" });

  const date = parsed.data.date;
  date.setHours(0, 0, 0, 0);
  const existing = await store.findStandupForDate(req.user!.id, date);

  if (existing) return res.status(409).json({ message: "Standup already submitted today" });

  const standup = await store.createStandup({
    userId: req.user!.id,
    date,
    tasks: parsed.data.tasks,
    attachmentName: req.file?.originalname,
    attachmentPath: req.file?.path,
    attachmentMimeType: req.file?.mimetype
  });

  return res.status(201).json(standup);
}));

router.get("/mine/today", requireAuth, requireRole(Role.USER), asyncHandler(async (req, res) => {
  const standup = await store.findStandupForDate(req.user!.id, startOfToday());

  return res.json({ submitted: Boolean(standup), standup });
}));

router.get("/mine", requireAuth, requireRole(Role.USER), asyncHandler(async (req, res) => {
  const standups = await store.listStandupsForUser(req.user!.id);

  return res.json(standups);
}));

router.get("/", requireAuth, requireRole(Role.SUPER_ADMIN, Role.ADMIN), asyncHandler(async (req, res) => {
  const standups = await store.listStandups({
    requesterRole: req.user!.role,
    requesterId: req.user!.id,
    date: req.query.date ? String(req.query.date) : undefined,
    status: req.query.status ? String(req.query.status) : undefined,
    role: req.query.role ? String(req.query.role) as Role : undefined,
    employee: req.query.employee ? String(req.query.employee) : undefined
  });

  return res.json(standups);
}));

router.get("/:id/attachment", requireAuth, asyncHandler(async (req, res) => {
  const standupId = String(req.params.id);
  const standup = await store.findStandupById(standupId);
  if (!standup?.attachmentPath || !standup.attachmentName) return res.status(404).json({ message: "Attachment not found" });

  if (req.user!.role === Role.USER && standup.userId !== req.user!.id) {
    return res.status(403).json({ message: "Forbidden" });
  }

  if (req.user!.role === Role.ADMIN) {
    const owner = await store.findUserById(standup.userId);
    if (owner?.adminId !== req.user!.id) return res.status(403).json({ message: "Forbidden" });
  }

  return res.download(standup.attachmentPath, standup.attachmentName);
}));

export default router;
