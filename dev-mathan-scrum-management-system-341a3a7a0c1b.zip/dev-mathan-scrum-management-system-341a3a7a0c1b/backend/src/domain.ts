export enum Role {
  SUPER_ADMIN = "SUPER_ADMIN",
  ADMIN = "ADMIN",
  USER = "USER"
}

export type StandupStatus = "SUBMITTED" | "PENDING";

export type User = {
  id: string;
  name: string;
  employeeId: string;
  email: string;
  role: Role;
  passwordHash?: string;
  isActive: boolean;
  adminId?: string;
  createdAt: string;
  updatedAt: string;
};

export type Otp = {
  id: string;
  codeHash: string;
  expiresAt: string;
  usedAt?: string;
  userId: string;
  createdAt: string;
};

export type StandupTask = {
  projectName: string;
  taskId: string;
  taskDescription: string;
  timeSpent: number;
  taskStatus: string;
  blockers?: string;
};

export type Standup = {
  id: string;
  date: string;
  tasks: StandupTask[];
  attachmentName?: string;
  attachmentPath?: string;
  attachmentMimeType?: string;
  status: StandupStatus;
  submittedAt: string;
  userId: string;
};
