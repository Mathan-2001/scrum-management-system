import nodemailer from "nodemailer";
import { config } from "./config.js";

async function getTransport() {
  if (!config.smtp.host || !config.smtp.user || !config.smtp.pass) {
    return undefined;
  }

  return nodemailer.createTransport({
    host: config.smtp.host,
    port: config.smtp.port,
    secure: config.smtp.port === 465,
    auth: {
      user: config.smtp.user,
      pass: config.smtp.pass
    }
  });
}

export async function sendEmail(to: string, subject: string, text: string) {
  const transport = await getTransport();

  if (!transport) {
    console.log(`[email:dev] To: ${to}\nSubject: ${subject}\n${text}`);
    return;
  }

  await transport.sendMail({
    to,
    from: config.smtp.from,
    subject,
    text
  });
}

export async function sendOtpEmail(email: string, code: string) {
  await sendEmail(
    email,
    "Your Scrum Management System OTP",
    `Your OTP is ${code}. It expires in 5 minutes.`
  );
}

export async function sendWelcomeEmail(input: {
  name: string;
  employeeId: string;
  role: string;
  email: string;
  password: string;
}) {
  await sendEmail(
    input.email,
    "Welcome to Scrum Management System",
    `Hi ${input.name},

Your account has been created successfully.

Employee ID
${input.employeeId}

Role
${input.role}

Email
${input.email}

Temporary Password
${input.password}

Login URL
${config.frontendUrl}

Thank You
Scrum Management Team`
  );
}
