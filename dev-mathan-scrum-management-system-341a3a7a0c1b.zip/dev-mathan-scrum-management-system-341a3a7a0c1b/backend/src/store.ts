import dotenv from "dotenv";
import path from "node:path";
import { PrismaClient } from "@prisma/client";
import { Otp, Role, Standup, StandupTask, User } from "./domain.js";

dotenv.config();
dotenv.config({ path: path.resolve(process.cwd(), "backend/.env") });
dotenv.config({ path: path.resolve(process.cwd(), ".env") });

type CreateUserInput = {
  name: string;
  employeeId: string;
  email: string;
  role: Role;
  adminId?: string;
  passwordHash?: string;
};

type CreateStandupInput = {
  userId: string;
  date: Date;
  tasks: StandupTask[];
  attachmentName?: string;
  attachmentPath?: string;
  attachmentMimeType?: string;
};

type UpdateUserInput = {
  name: string;
  employeeId: string;
  email: string;
  role: Role;
};

const prisma = new PrismaClient();

function dayKey(date: Date | string) {
  const value = typeof date === "string" ? new Date(date) : new Date(date);
  value.setHours(0, 0, 0, 0);
  return value;
}

function toIso(value: Date | null | undefined) {
  return value ? value.toISOString() : undefined;
}

function mapUser(user: any): User {
  return {
    id: user.id,
    name: user.name,
    employeeId: user.employeeId,
    email: user.email,
    role: user.role as Role,
    passwordHash: user.passwordHash ?? undefined,
    isActive: user.isActive,
    adminId: user.adminId ?? undefined,
    createdAt: toIso(user.createdAt)!,
    updatedAt: toIso(user.updatedAt)!
  };
}

function mapOtp(otp: any): Otp {
  return {
    id: otp.id,
    codeHash: otp.codeHash,
    expiresAt: toIso(otp.expiresAt)!,
    usedAt: toIso(otp.usedAt),
    userId: otp.userId,
    createdAt: toIso(otp.createdAt)!
  };
}

function mapStandup(standup: any): Standup {
  return {
    id: standup.id,
    date: toIso(standup.date)!,
    tasks: [...(standup.tasks ?? [])]
      .sort((a, b) => a.order - b.order)
      .map((task) => ({
        projectName: task.projectName,
        taskId: task.taskId,
        taskDescription: task.taskDescription,
        timeSpent: task.timeSpent,
        taskStatus: task.taskStatus,
        blockers: task.blockers ?? undefined
      })),
    attachmentName: standup.attachmentName ?? undefined,
    attachmentPath: standup.attachmentPath ?? undefined,
    attachmentMimeType: standup.attachmentMimeType ?? undefined,
    status: standup.status,
    submittedAt: toIso(standup.submittedAt)!,
    userId: standup.userId
  };
}

class PrismaStore {
  private seedPromise?: Promise<void>;

  private async ensureSeeded() {
    this.seedPromise ??= this.seed();
    await this.seedPromise;
  }

  private async seed() {
    const existingUsers = await prisma.user.count();
    if (existingUsers > 0) return;

    await prisma.user.create({
      data: {
        id: "user_super_admin",
        name: "Super Admin",
        employeeId: "EMP001",
        email: "superadmin@scrum.local",
        role: Role.SUPER_ADMIN
      }
    });

    await prisma.user.create({
      data: {
        id: "user_team_admin",
        name: "Team Admin",
        employeeId: "EMP010",
        email: "admin@scrum.local",
        role: Role.ADMIN
      }
    });

    await prisma.user.create({
      data: {
        id: "user_mathan",
        name: "Mathan",
        employeeId: "EMP101",
        email: "mathan@scrum.local",
        role: Role.USER,
        adminId: "user_team_admin"
      }
    });
  }

  async findUserByEmail(email: string) {
    await this.ensureSeeded();
    const user = await prisma.user.findFirst({
      where: { email: { equals: email, mode: "insensitive" } }
    });
    return user ? mapUser(user) : undefined;
  }

  async findUserById(userId: string) {
    await this.ensureSeeded();
    const user = await prisma.user.findUnique({ where: { id: userId } });
    return user ? mapUser(user) : undefined;
  }

  async findUserByEmailOrEmployeeId(email: string, employeeId: string) {
    await this.ensureSeeded();
    const user = await prisma.user.findFirst({
      where: {
        OR: [
          { email: { equals: email, mode: "insensitive" } },
          { employeeId }
        ]
      }
    });
    return user ? mapUser(user) : undefined;
  }

  async latestOpenOtp(userId: string) {
    await this.ensureSeeded();
    const otp = await prisma.otp.findFirst({
      where: { userId, usedAt: null },
      orderBy: { createdAt: "desc" }
    });
    return otp ? mapOtp(otp) : undefined;
  }

  async createOtp(userId: string, codeHash: string, expiresAt: Date) {
    await this.ensureSeeded();
    await prisma.otp.create({
      data: { userId, codeHash, expiresAt }
    });
  }

  async markOtpUsed(otpId: string) {
    await this.ensureSeeded();
    await prisma.otp.update({
      where: { id: otpId },
      data: { usedAt: new Date() }
    });
  }

  async listUsers(adminId?: string) {
    await this.ensureSeeded();
    const users = await prisma.user.findMany({
      where: adminId ? { adminId } : undefined,
      orderBy: { createdAt: "desc" }
    });
    return users.map(mapUser);
  }

  async createUser(input: CreateUserInput) {
    await this.ensureSeeded();
    const user = await prisma.user.create({
      data: {
        name: input.name,
        employeeId: input.employeeId,
        email: input.email,
        role: input.role,
        adminId: input.adminId,
        passwordHash: input.passwordHash
      }
    });
    return mapUser(user);
  }

  async updateUserPassword(userId: string, passwordHash: string) {
    await this.ensureSeeded();
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return undefined;

    const updated = await prisma.user.update({
      where: { id: userId },
      data: { passwordHash }
    });
    return mapUser(updated);
  }

  async updateUser(userId: string, input: UpdateUserInput) {
    await this.ensureSeeded();
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return undefined;
    if (user.role === Role.SUPER_ADMIN) return false;

    const updated = await prisma.user.update({
      where: { id: userId },
      data: {
        name: input.name,
        employeeId: input.employeeId,
        email: input.email,
        role: input.role,
        adminId: input.role === Role.USER ? user.adminId : null
      }
    });
    return mapUser(updated);
  }

  async deleteUser(userId: string) {
    await this.ensureSeeded();
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) return undefined;
    if (user.role === Role.SUPER_ADMIN) return false;

    await prisma.$transaction([
      prisma.user.updateMany({
        where: { adminId: userId },
        data: { adminId: null }
      }),
      prisma.user.delete({ where: { id: userId } })
    ]);
    return true;
  }

  async countUsers(where: Partial<Pick<User, "role" | "adminId">> = {}) {
    await this.ensureSeeded();
    return prisma.user.count({
      where: {
        role: where.role,
        adminId: where.adminId
      }
    });
  }

  async findStandupForDate(userId: string, date: Date) {
    await this.ensureSeeded();
    const standup = await prisma.standup.findUnique({
      where: { userId_date: { userId, date: dayKey(date) } },
      include: { tasks: true }
    });
    return standup ? mapStandup(standup) : undefined;
  }

  async countStandupsForDate(date: Date, adminId?: string) {
    await this.ensureSeeded();
    return prisma.standup.count({
      where: {
        date: dayKey(date),
        user: adminId ? { adminId } : undefined
      }
    });
  }

  async createStandup(input: CreateStandupInput) {
    await this.ensureSeeded();
    const standup = await prisma.standup.create({
      data: {
        userId: input.userId,
        date: dayKey(input.date),
        attachmentName: input.attachmentName,
        attachmentPath: input.attachmentPath,
        attachmentMimeType: input.attachmentMimeType,
        status: "SUBMITTED",
        tasks: {
          create: input.tasks.map((task, index) => ({
            order: index,
            projectName: task.projectName,
            taskId: task.taskId,
            taskDescription: task.taskDescription,
            timeSpent: task.timeSpent,
            taskStatus: task.taskStatus,
            blockers: task.blockers
          }))
        }
      },
      include: { tasks: true }
    });
    return mapStandup(standup);
  }

  async listStandups(filters: {
    requesterRole: Role;
    requesterId: string;
    date?: string;
    status?: string;
    role?: Role;
    employee?: string;
  }) {
    await this.ensureSeeded();

    const userWhere: Record<string, unknown> = {};
    if (filters.requesterRole === Role.ADMIN) userWhere.adminId = filters.requesterId;
    if (filters.role) userWhere.role = filters.role;
    if (filters.employee) {
      userWhere.employeeId = { contains: filters.employee, mode: "insensitive" };
    }

    const standups = await prisma.standup.findMany({
      where: {
        date: filters.date ? dayKey(filters.date) : undefined,
        status: filters.status as any,
        user: Object.keys(userWhere).length > 0 ? userWhere : undefined
      },
      include: {
        tasks: true,
        user: {
          select: {
            name: true,
            employeeId: true,
            role: true
          }
        }
      },
      orderBy: { submittedAt: "desc" }
    });

    return standups.map((standup) => ({
      ...mapStandup(standup),
      user: {
        name: standup.user.name,
        employeeId: standup.user.employeeId,
        role: standup.user.role as Role
      }
    }));
  }

  async listStandupsForUser(userId: string) {
    await this.ensureSeeded();
    const standups = await prisma.standup.findMany({
      where: { userId },
      include: { tasks: true },
      orderBy: { date: "desc" }
    });
    return standups.map(mapStandup);
  }

  async findStandupById(standupId: string) {
    await this.ensureSeeded();
    const standup = await prisma.standup.findUnique({
      where: { id: standupId },
      include: { tasks: true }
    });
    return standup ? mapStandup(standup) : undefined;
  }
}

export const store = new PrismaStore();
